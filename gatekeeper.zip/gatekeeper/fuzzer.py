#!/usr/bin/env python3

import sys
import socket
import time

def main(ip, port, message, salt):
    while True:
        try: 
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((ip, port))
                s.recv(1024)
                print(f'Fuzzing with {len(message)} bytes')
                s.send(bytes(message + salt, "latin-1"))  
                s.recv(1024)  
        except Exception as e:  
            print(f'Fuzzing crashed at {len(message)} bytes: {e}')
            sys.exit(0)

        message += 100 * "A"
        time.sleep(1)

if __name__ == '__main__':
    ip = '127.0.0.1'
    port = 31337
    message = 'A' * 100
    salt = '\r\n'
    main(ip, port, message,salt)
